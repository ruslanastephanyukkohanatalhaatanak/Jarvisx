JARVIS X5 ANDROID PROJESİ

Bu paket HTML arayüzünü Android WebView içinde açan Android Studio projesidir.
HTML dosyası app/src/main/assets/index.html içinde uygulamaya gömülüdür.

APK oluşturma:
1. Bilgisayarda Android Studio kurulu olsun.
2. Android Studio > Open ile JarvisX5 klasörünü açın.
3. Gradle senkronizasyonu tamamlanana kadar bekleyin (internet gerekebilir; Android SDK 35 ve JDK 17 gerekir).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK genellikle app/build/outputs/apk/debug/app-debug.apk yoluna çıkar.
6. APK'yı telefona gönderin ve açarak kurun. Android, bilinmeyen uygulama kurulum izni isteyebilir.

NOTLAR:
- Bu ortamda Android SDK/Gradle derleyicisi bulunmadığından APK'nın kendisi burada derlenmedi; kaynak proje hazırlandı.
- Sesli komut işlevi Android WebView/cihaz konuşma tanıma desteğine bağlıdır ve internet isteyebilir.
- HTML içindeki Google Fonts bağlantısı varsa ilk yüklemede internet bağlantısı gerektirebilir; temel arayüz dosyanın içindedir.
